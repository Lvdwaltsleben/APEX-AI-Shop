import {init,pool} from '../db.js';
import {bossCycle} from '../agents.js';
try{await init();const result=await bossCycle();console.log('APEX Boss cycle',JSON.stringify(result))}catch(e){console.error('Cron cycle failed',e);process.exitCode=1}finally{await pool.end()}
