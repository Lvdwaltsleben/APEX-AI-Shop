import crypto from 'node:crypto';
import {query,config,setConfig} from './db.js';
const uid=()=>crypto.randomUUID();
const clean=x=>String(x||'').trim();
const aiKey=()=>!!process.env.GEMINI_API_KEY;
function parseJson(s){const t=s.replace(/^```(?:json)?\s*|\s*```$/g,'').trim();return JSON.parse(t)}
async function gemini(role,instructions){
 if(!aiKey()) throw Error('GEMINI_API_KEY not configured');
 const model=process.env.GEMINI_MODEL||'gemini-2.5-flash';
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),45000);
 try{
 const res=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':process.env.GEMINI_API_KEY},body:JSON.stringify({contents:[{role:'user',parts:[{text:`You are APEX ${role}, a cautious digital-products business agent. Do not invent real-world sales figures, endorsements, or unverified factual claims. Reply with ONE valid JSON object and no markdown. ${instructions}`}]}],generationConfig:{responseMimeType:'application/json',temperature:0.55}}),signal:controller.signal});
 const v=await res.json();if(!res.ok)throw Error('AI provider: '+(v.error?.message||res.status));return parseJson(v.candidates?.[0]?.content?.parts?.map(x=>x.text||'').join('')||'{}')
 }finally{clearTimeout(timer)}
}
async function task(agent,description,fn){const id=uid();await query('INSERT INTO tasks(id,agent,description) VALUES($1,$2,$3)',[id,agent,description]);try{const result=await fn();await query("UPDATE tasks SET status='done', result=$2,updated_at=now() WHERE id=$1",[id,clean(result).slice(0,700)]);return result}catch(e){await query("UPDATE tasks SET status='blocked', result=$2,updated_at=now() WHERE id=$1",[id,clean(e.message).slice(0,700)]);throw e}}
const topics=['spreadsheet template','freelancer invoice template','construction safety checklist','small business budget planner','social media content calendar','job application tracker','project management checklist','personal finance planner','customer onboarding checklist','study planner'];
export async function scan(){
 const found=[];
 for(const topic of topics){
  const url='https://hn.algolia.com/api/v1/search?query='+encodeURIComponent(topic)+'&tags=story&hitsPerPage=8';
  try{const response=await fetch(url,{signal:AbortSignal.timeout(9000)});if(!response.ok)continue;const data=await response.json();const hits=(data.hits||[]).filter(x=>x.title&&x.objectID);if(!hits.length)continue;
   const interest=Math.min(100,Math.round(12+hits.length*4+hits.reduce((n,h)=>n+Math.min(30,Number(h.points)||0),0)/5));
   const top=hits[0],source=top.url?.startsWith('https://')?top.url:`https://news.ycombinator.com/item?id=${encodeURIComponent(top.objectID)}`;
   await query(`INSERT INTO opportunities(id,topic,interest,source_url,summary,scanned_at) VALUES($1,$2,$3,$4,$5,now()) ON CONFLICT(topic) DO UPDATE SET interest=EXCLUDED.interest,source_url=EXCLUDED.source_url,summary=EXCLUDED.summary,scanned_at=now()`,[uid(),topic,interest,source,`${hits.length} matching Hacker News posts; interest score is NOT verified sales data`]);found.push({topic,interest,source});
  }catch{/* ignore individual source failure */}
 }
 return found;
}
function validateProduct(p){const issues=[];if(clean(p.title).length<12||clean(p.title).length>110)issues.push('Invalid title');if(clean(p.description).length<60||clean(p.description).length>900)issues.push('Invalid description');if(clean(p.content).length<1400||clean(p.content).length>50000)issues.push('Incomplete or oversized content');if(!Number.isInteger(p.price_zar)||p.price_zar<20||p.price_zar>2500)issues.push('Price out of allowed range');if(/guaranteed (income|profit|sales)|copyrighted (book|course)|100% success/i.test(Object.values(p).join(' ')))issues.push('Unsafe or unsupported claim');return issues}
async function productWork(op,s){
 let existing=(await query('SELECT * FROM products WHERE topic=$1 LIMIT 1',[op.topic])).rows[0];
 if(existing&&(!s.auto_refresh||Date.now()-Date.parse(existing.updated_at)<14*86400000))return 'Product current: '+existing.title;
 if(!existing&&!s.auto_create)return 'Product creation disabled';
 if(!existing&&(await query('SELECT count(*)::int AS n FROM products')).rows[0].n>=30)return 'Product limit reached';
 const product=await task('Product Agent',(existing?'Refresh':'Create')+' '+op.topic,async()=>{
  const out=await gemini('Product Agent',`Make an original, useful, practical downloadable PLAIN TEXT toolkit for the need '${op.topic}'. Use specific steps, 2 worked examples, ready-to-copy templates, and a quality checklist. Market interest proxy: ${op.summary}; source: ${op.source_url}. Do not claim this proves sales. Return JSON {"title":"...","description":"...","price_zar":integer,"content":"..."}. Content minimum 1800 characters, aim for 3000-5000. Avoid unsupported regulatory advice.`);return JSON.stringify(out)
 });
 const draft=JSON.parse(product),issues=validateProduct(draft);
 if(!issues.length){try{const qa=await task('Quality Agent','Check original toolkit quality',async()=>{const r=await gemini('Quality Agent',`Review the following product for usefulness, incompleteness, plagiarism or unreliable claims. Return JSON {"approved":boolean,"issues":["..."],"summary":"..."}. Product: ${JSON.stringify(draft).slice(0,12500)}`);return JSON.stringify(r)});const verdict=JSON.parse(qa);if(verdict.approved!==true)issues.push(...(verdict.issues||['Quality check rejected']));}catch(e){issues.push('Quality model unavailable: '+e.message)}}
 if(issues.length){await task('Main Boss','Blocked unsuitable product',async()=>issues.join('; '));return 'Draft rejected: '+issues.join('; ')}
 // For safety, do not silently overwrite existing published content; put updated copy into owner review.
 if(existing){await task('Main Boss','Product update awaiting review: '+existing.title,async()=>`New draft ready (not replacing live item): ${draft.title}; ${draft.description}`);return 'Update proposed; existing product preserved'}
 const enabled=(await config()).enabled;
 const publish=!!(s.auto_publish&&enabled);
 const id=uid();await query('INSERT INTO products(id,title,description,price_cents,content,published,topic,review_notes) VALUES($1,$2,$3,$4,$5,$6,$7,$8)',[id,clean(draft.title).slice(0,110),clean(draft.description).slice(0,900),draft.price_zar*100,clean(draft.content),publish,op.topic,publish?'Automated checks passed; independent review recommended':'Awaiting owner approval']);return publish?'Published original product: '+draft.title:'Draft created for review: '+draft.title
}
async function marketingWork(s){if(!s.auto_marketing)return 'Marketing disabled';const row=(await query(`SELECT p.* FROM products p WHERE p.published=true AND NOT EXISTS (SELECT 1 FROM campaigns c WHERE c.product_id=p.id AND c.created_at>now()-interval '7 days') ORDER BY p.created_at LIMIT 1`)).rows[0];if(!row)return 'No published product currently needs promotion';const result=await task('Marketing Agent','Market '+row.title,async()=>JSON.stringify(await gemini('Marketing Agent',`Create truthful campaign copy for an actual product with title ${JSON.stringify(row.title)}, description ${JSON.stringify(row.description)}, price R${row.price_cents/100}. JSON keys: headline (15-85 characters), body (70-220 characters), social_caption (30-500 characters). Do not invent discounts, reviews, benefits, guarantees, testimonials, or urgency. No external posting.`)));
 const m=JSON.parse(result);if(clean(m.headline).length<15||clean(m.headline).length>85||clean(m.body).length<70||clean(m.body).length>220||clean(m.social_caption).length<30) return 'Campaign failed content validation';const enabled=(await config()).enabled;await query('INSERT INTO campaigns(id,product_id,headline,body,social_caption,published) VALUES($1,$2,$3,$4,$5,$6)',[uid(),row.id,clean(m.headline),clean(m.body),clean(m.social_caption),!!s.auto_site_promotions&&enabled]);return 'Marketing campaign created for '+row.title+'; outside-platform posting not connected'}
export async function bossCycle(){
 // Postgres session advisory lock prevents overlapping cron/owner runs.
 const client=await (await import('./db.js')).pool.connect();let locked=false;
 try{const l=await client.query('SELECT pg_try_advisory_lock(770017) AS ok');locked=l.rows[0].ok;if(!locked)return {skipped:true,summary:'Boss cycle already running'};
 let s=await config();if(!s.enabled)return {skipped:true,summary:'APEX STOPPED — no new agent work'};
 if(!aiKey())return {skipped:true,summary:'AI key missing — setup required; no fake agent results'};
 const details=[];let results=[];
 try{results=await task('Research Agent','Scan public interest indicators',async()=>{const r=await scan();details.push('Research found '+r.length+' topics');return JSON.stringify(r)}) .then(x=>JSON.parse(x))}catch(e){details.push('Research blocked: '+e.message)}
 const options=(await query('SELECT * FROM opportunities ORDER BY interest DESC,scanned_at DESC LIMIT 6')).rows;
 if(options.length){try{const chosen=await task('Main Boss','Select sourced market opportunity',async()=>{const verdict=await gemini('Main Boss',`Choose the best opportunity for a useful original downloadable business tool. Public interest only, not actual sales. Choose ONLY a topic from ${JSON.stringify(options.map(o=>({topic:o.topic,interest:o.interest,source:o.source_url})))}. Return JSON {"topic":"exact topic","reason":"..."}.`);return JSON.stringify(verdict)});const topic=JSON.parse(chosen).topic;const op=options.find(o=>o.topic===topic)||options[0];details.push(await productWork(op,s))}catch(e){details.push('Product loop blocked: '+e.message)}}
 if(!(await config()).enabled)details.push('Stopped during cycle; skipped marketing');else try{details.push(await marketingWork(s))}catch(e){details.push('Marketing blocked: '+e.message)}
 const summary=details.join(' | ').slice(0,1500)||'No agent work completed';await query('INSERT INTO cycles(id,summary,details) VALUES($1,$2,$3)',[uid(),summary,JSON.stringify({topics:results,decisions:details})]);await setConfig({...await config(),last_cycle:new Date().toISOString()});return {summary,details};
 }finally{if(locked)await client.query('SELECT pg_advisory_unlock(770017)');client.release()}
}
