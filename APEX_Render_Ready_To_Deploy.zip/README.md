# APEX — Render deployment (real backend)

APEX is a Node.js/Express + PostgreSQL app with a public digital-products storefront, password-protected owner Back Office, Main Boss AI workflow, public-source market research, product drafting, on-site marketing and Paystack checkout. Revenue is based on verified paid orders; **R500,000 per month is only a target, not a guarantee**.

## First deployment — test/free configuration

1. Unzip this project and upload **the contents of this folder** to a NEW GitHub repository. `render.yaml` must be at the repo root. Do not upload any real `.env` file or secrets.
2. Go to https://dashboard.render.com/ and select **New → Blueprint**. Link your GitHub repository and choose the `render.yaml` file. Follow the Render prompts. Render will create one web service and one database.
3. During Blueprint creation enter: `APEX_OWNER_PASSWORD` (at least 12 characters, choose a new unique password); `APP_ORIGIN` (the exact HTTPS URL Render gives you, e.g. `https://apex-commerce.onrender.com`); optionally `GEMINI_API_KEY` (from Google AI Studio) and `PAYSTACK_SECRET_KEY` (from your Paystack business). You can set/adjust values under **Environment** after creation; redeploy changes when prompted. The generated `SESSION_SECRET` must remain secret. If `APP_ORIGIN` was not known at creation, enter it after the URL is assigned and redeploy.
4. Visit `https://YOUR-SERVICE.onrender.com/api/health`; you should see a JSON health result. Visit the main address, click **Back Office**, then enter your owner password.
5. In Back Office, select **START**. For a first test choose **Run Boss cycle**. With a valid Gemini API key, this can query public Hacker News interest signals and draft a product. The quality check may reject some drafts.
6. Review drafts, then explicitly publish one if appropriate. A Paystack key is required before anyone can buy. Configure Paystack's **webhook URL** as `https://YOUR-SERVICE.onrender.com/api/webhook`. Make a low-value test purchase with Paystack test credentials before enabling real payments. Never add keys to the public HTML.

## Production — actually scheduled operations

The `render.yaml` configuration is for **testing**. The free Render web service goes idle; the free PostgreSQL database expires after 30 days. It does **not** include an autonomous cron job.

For a production installation, replace `render.yaml` with `render.production.yaml` in the **repo root** on a separate branch or before initial deployment. Review pricing and provision the paid web, database, and cron resources. The production Blueprint runs `scripts/cron.js` at `0 */6 * * *` (UTC). Cron checks the database-backed START/STOP setting before creating any tasks. Note: switching from free to paid can require a Render database migration/upgrade plan; back up data first. Do not create a second database accidentally.

## What START / STOP actually do

START enables agent work. A running production cron executes approximately every six hours. **Run Boss cycle** triggers one cycle manually. STOP prevents future cycles and suppresses marketing in an ongoing cycle after its current task; it does not instantly kill an in-flight API request. Checkout and existing published products remain online when STOP is pressed. These controls do not spend advertising money or publish to external social accounts.

## Functionality and limits

- Research uses a list of predefined topics and public Hacker News search signals, **not verified bestseller sales** or an unlimited web crawler.
- Gemini can create original plain-text toolkits; quality-agent output is another AI judgement, not a legal or copyright certification.
- `auto_publish` defaults to **OFF**. Turn it on only after product and legal checks are configured.
- Product refreshes are currently proposed as owner-review tasks; existing published content is **not** overwritten automatically.
- Marketing drafts and on-site promotions work after AI setup. Posting to Facebook/Instagram/email or paid advertising requires separate, authorized integrations and is **not implemented**.
- Product delivery is a text download after confirmed Paystack payment; this edition does not create PDFs or course videos.
- Customers can purchase without a login; a confirmed download link lasts one hour. Customers should keep their checkout receipt and contact the store owner for support; there is no automatic email integration in this edition.
- Paid production services, Gemini usage and payment processing may incur costs. Revenue is not profit.

## App architecture

`server.js` — HTTP routes, auth, verified payment and downloads.
`db.js` — PostgreSQL migrations and configuration.
`agents.js` — research, boss, product, QA, marketing and cycle locking.
`public/` — website and owner dashboard.
`scripts/cron.js` — scheduled cycle runner.
`render.yaml` — free trial Blueprint.
`render.production.yaml` — paid scheduling configuration to use instead of render.yaml.

## Local development

Requires Node 20+ and PostgreSQL. Set environment variables in your terminal (see `.env.example`; this project does not automatically load `.env`). Run `npm install`, `npm run check`, and `npm start`. `DATABASE_URL` is required. Open http://localhost:3000. Do not put actual credentials in source control.

**Security note:** This is an initial commerce implementation, not a security audit. Before large-scale sales, add persistent rate limiting, refunds and customer support, compliance/privacy notices, stricter webhook/checkout monitoring and backup/restore tests.
