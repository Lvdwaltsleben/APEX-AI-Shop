import pg from 'pg';
if(!process.env.DATABASE_URL) throw Error('DATABASE_URL is required');
export const pool=new pg.Pool({connectionString:process.env.DATABASE_URL, max:5,connectionTimeoutMillis:10000,ssl:process.env.DATABASE_URL.includes('localhost')?false:undefined});
export const query=(sql,args=[])=>pool.query(sql,args);
export async function init(){
 await query(`CREATE TABLE IF NOT EXISTS config(key text primary key,value jsonb not null)`);
 await query(`INSERT INTO config(key,value) VALUES ('automation','{"enabled":false,"auto_create":true,"auto_refresh":true,"auto_publish":false,"auto_marketing":true,"auto_site_promotions":true,"target_zar":500000,"last_cycle":null}'::jsonb) ON CONFLICT DO NOTHING`);
 await query(`CREATE TABLE IF NOT EXISTS products(id uuid primary key,title text not null, description text not null, price_cents int not null check(price_cents>=100), content text not null, published boolean not null default false, topic text, updated_at timestamptz not null default now(), created_at timestamptz not null default now(), review_notes text not null default '', version int not null default 1)`);
 await query(`CREATE TABLE IF NOT EXISTS opportunities(id uuid primary key,topic text not null unique,interest int not null, source_url text not null, summary text not null, scanned_at timestamptz not null default now())`);
 await query(`CREATE TABLE IF NOT EXISTS campaigns(id uuid primary key,product_id uuid references products(id) on delete cascade,headline text not null,body text not null,social_caption text not null, published boolean not null default false, external_status text not null default 'not_connected', created_at timestamptz not null default now())`);
 await query(`CREATE TABLE IF NOT EXISTS tasks(id uuid primary key,agent text not null,description text not null,status text not null default 'started',result text not null default '',created_at timestamptz not null default now(),updated_at timestamptz not null default now())`);
 await query(`CREATE TABLE IF NOT EXISTS cycles(id uuid primary key,summary text not null,details jsonb not null default '{}'::jsonb,created_at timestamptz not null default now())`);
 await query(`CREATE TABLE IF NOT EXISTS orders(id uuid primary key, product_id uuid references products(id), email text not null, reference text not null unique, amount_cents int not null, currency text not null default 'ZAR', status text not null default 'pending', download_token_hash text, paid_at timestamptz, created_at timestamptz not null default now())`);
}
export async function config(){const r=await query("SELECT value FROM config WHERE key='automation'");return r.rows[0].value}
export async function setConfig(v){const r=await query("UPDATE config SET value=$1::jsonb WHERE key='automation' RETURNING value",[JSON.stringify(v)]);return r.rows[0].value}
